package com.vitormarcos.trabalhofinal.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.vitormarcos.trabalhofinal.R

@Composable
fun HomeScreen(navController: NavController) {
    // Usando Scaffold para adicionar o botão de emergência no rodapé
    Scaffold(
        bottomBar = {
            BottomAppBar(
                backgroundColor = Color(0xFF00796B), // Cor do botão de emergência
                contentColor = Color.White,
                elevation = 10.dp
            ) {
                Button(
                    onClick = {
                        // Ação do botão de emergência (abre a tela de telefone com o número 190)
                        Toast.makeText(navController.context, "Ligando para emergência...", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red)
                ) {
                    Text(text = "EMERGÊNCIA", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { paddingValues -> // Adiciona paddingValues para o conteúdo da tela
        // Fundo branco para a tela
        Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .padding(paddingValues), // Adiciona o padding fornecido pelo Scaffold
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Logo da iPharm
                Image(
                    painter = painterResource(id = R.drawable.ipharm_logo), // Altere para o ID do seu logo
                    contentDescription = "Logo da iPharm",
                    modifier = Modifier.height(200.dp)
                )

                // Botões de Login e Cadastro
                Column(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { navController.navigate("login_screen") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    ) {
                        Text(text = "Login", modifier = Modifier.padding(16.dp))
                    }

                    Button(
                        onClick = { navController.navigate("signup_screen") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "Cadastrar", modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}
