package com.vitormarcos.trabalhofinal.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.vitormarcos.trabalhofinal.data.entities.Remedio
import androidx.compose.ui.res.painterResource
import androidx. compose. foundation. layout. R

@Composable
fun CatalogScreen() {

    val remedios = listOf(
        Remedio(1, "Paracetamol", "Para febre e dor.", 10.0, R.drawable.paracetamol),
        Remedio(2, "Ibuprofeno", "Anti-inflamatório.", 15.0, R.drawable.paracetamol),
        Remedio(3, "Amoxicilina", "Antibiótico.", 20.0, R.drawable.paracetamol)
    )

    // Usando LazyColumn para listar os remédios
    LazyColumn(modifier = Modifier.padding(16.dp)) {
        items(remedios) { remedio ->
            CatalogItem(remedio)  // Exibe cada item do catálogo
            Spacer(modifier = Modifier.height(16.dp))  // Espaçamento entre os itens
        }
    }
}

@Composable
fun CatalogItem(remedio: Remedio) {
    // Usando Row para alinhar imagem e textos
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp), // Melhorar o espaçamento
        horizontalArrangement = Arrangement.Start
    ) {
        // Exibe a imagem do remédio usando o ID do recurso 'foto'
        Image(
            painter = painterResource(id = remedio.foto), // Usa o ID do recurso drawable
            contentDescription = remedio.nome,
            modifier = Modifier.size(64.dp)  // Tamanho da imagem
        )
        Spacer(modifier = Modifier.width(16.dp))  // Espaçamento entre imagem e textos

        // Exibe os textos do remédio
        Column(
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.weight(1f)  // Faz os textos se expandirem conforme necessário
        ) {
            Text(text = remedio.nome, fontWeight = FontWeight.Bold)
            Text(text = remedio.descricao, color = Color.Gray)
            Text(text = "R$ ${remedio.preco}", color = Color.Black)  // Exibe o preço
        }
    }
}
