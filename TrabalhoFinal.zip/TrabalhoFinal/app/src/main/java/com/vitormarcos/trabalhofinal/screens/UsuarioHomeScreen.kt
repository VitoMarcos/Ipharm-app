package com.vitormarcos.trabalhofinal.screens

import android.widget.Toast
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.vitormarcos.trabalhofinal.R

@Composable
fun UsuarioHomeScreen(navController: NavController, nomeUsuario: String) {
    Scaffold(
        bottomBar = {
            BottomAppBar(
                backgroundColor = Color(0xFF00796B), // Cor do botão de emergência
                contentColor = Color.White,
                elevation = 10.dp
            ) {
                Button(
                    onClick = {
                        // Ação do botão de emergência (abre a tela de telefone com o número 190)
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:190"))
                        navController.context.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red)
                ) {
                    Text(text = "EMERGÊNCIA", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { paddingValues -> // Adiciona paddingValues para o conteúdo da tela
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .padding(paddingValues), // Adiciona o padding que é passado pelo Scaffold
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Logo da iPharm no canto superior esquerdo
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                Image(
                    painter = painterResource(id = R.drawable.ipharm_logo), // Substitua com a logo da iPharm
                    contentDescription = "Logo iPharm",
                    modifier = Modifier.size(50.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Mensagem de boas-vindas
            Text(
                text = "BEM VINDO, $nomeUsuario",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Botão de catálogo de remédios
            Button(
                onClick = {
                    navController.navigate("catalogo_screen")
                    NotificationHelper.sendNotification(
                        navController.context,
                        "Catálogo de Remédios",
                        "Você abriu o Catálogo de Remédios!"
                    )
                },
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF00796B))
            ) {
                Text(text = "Catálogo de Remédios", color = Color.White)
            }

            // Botão de carrinho
            Button(
                onClick = {
                    navController.navigate("cart_screen")
                    NotificationHelper.sendNotification(
                        navController.context,
                        "Carrinho",
                        "Você abriu o Carrinho!"
                    )
                },
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF00796B))
            ) {
                Text(text = "Carrinho", color = Color.White)
            }

            // Botão de meus pedidos
            Button(
                onClick = {
                    navController.navigate("meus_pedidos_screen")
                    NotificationHelper.sendNotification(
                        navController.context,
                        "Meus Pedidos",
                        "Você abriu a tela de Meus Pedidos!"
                    )
                },
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF00796B))
            ) {
                Text(text = "Meus Pedidos", color = Color.White)
            }
        }
    }
}
