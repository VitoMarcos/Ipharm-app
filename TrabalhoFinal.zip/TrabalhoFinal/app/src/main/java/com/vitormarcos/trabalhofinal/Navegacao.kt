package com.vitormarcos.trabalhofinal

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.vitormarcos.trabalhofinal.screens.CartScreen
import com.vitormarcos.trabalhofinal.screens.CatalogScreen
import com.vitormarcos.trabalhofinal.screens.HomeScreen
import com.vitormarcos.trabalhofinal.screens.LoginScreen
import com.vitormarcos.trabalhofinal.screens.OrdersScreen
import com.vitormarcos.trabalhofinal.screens.SignUpScreen
import com.vitormarcos.trabalhofinal.screens.UsuarioHomeScreen

@Composable
fun AppNavHost(navController: NavHostController) {

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") { HomeScreen(navController) }
        composable("login") { LoginScreen(navController) }
        composable("cadastro") { SignUpScreen(navController) }
        composable("usuario_home/{nomeUsuario}") { backStackEntry ->
            UsuarioHomeScreen(navController, backStackEntry.arguments?.getString("nomeUsuario") ?: "")
        }
        composable("catalog") { CatalogScreen() }
        composable("carrinho") { CartScreen() }
        composable("pedidos") { OrdersScreen() }
    }
}

@Composable
@Preview
fun PreviewApp() {
    val navController = rememberNavController()
    AppNavHost(navController)
}
