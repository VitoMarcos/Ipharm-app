package com.vitormarcos.trabalhofinal.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Button
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.material.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.vitormarcos.trabalhofinal.database.AppDatabase
import com.vitormarcos.trabalhofinal.data.entities.Usuario
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun SignUpScreen(navController: NavController) {
    var nome by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }
    var cpf by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val db = AppDatabase.getDatabase(context = navController.context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Campo de Nome
        OutlinedTextField(
            value = nome,
            onValueChange = { nome = it },
            label = { Text("Nome") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Campo de E-mail
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("E-mail") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Campo de Senha
        OutlinedTextField(
            value = senha,
            onValueChange = { senha = it },
            label = { Text("Senha") },
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions.Default.copy(
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    // Fechar o teclado ou mover para outro campo
                }
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Campo de CPF
        OutlinedTextField(
            value = cpf,
            onValueChange = { cpf = it },
            label = { Text("CPF") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Botão de Cadastro
        Button(
            onClick = {
                isLoading = true
                // Criação do usuário no banco de dados
                val usuario = Usuario(
                    nome = nome,
                    email = email,
                    senha = senha,
                    cpf = cpf
                )
                CoroutineScope(Dispatchers.IO).launch {
                    val existingUser = db.usuarioDao().getUserByEmail(email)
                    if (existingUser != null) {
                        // Exibir erro se o e-mail já estiver cadastrado
                        // Exemplo de erro
                    } else {
                        db.usuarioDao().insert(usuario)
                        // Após cadastrar, redirecionar para a tela de login
                        navController.navigate("login_screen")
                    }
                }
                isLoading = false
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading
        ) {
            Text(text = if (isLoading) "Cadastrando..." else "Cadastrar")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Link para a tela de login
        TextButton(onClick = { navController.navigate("login_screen") }) {
            Text("Já tem uma conta? Faça login")
        }
    }
}
