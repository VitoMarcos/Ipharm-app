package com.vitormarcos.trabalhofinal.data.entities.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.vitormarcos.trabalhofinal.data.entities.CartItem

@Dao
interface CartItemDao {
    @Insert
    suspend fun insert(cartItem: CartItem)

    @Update
    suspend fun update(cartItem: CartItem)

    @Query("SELECT * FROM cart_items WHERE id = :id")
    suspend fun getById(id: Long): CartItem?

    // Função para deletar item pelo ID
    @Query("DELETE FROM cart_items WHERE id = :cartItemId")
    suspend fun deleteById(cartItemId: Int)

    @Query("DELETE FROM cart_items")
    suspend fun deleteAllCartItems()

    @Query("SELECT * FROM cart_items")
    suspend fun getAll(): List<CartItem>

    @Delete
    suspend fun deleteCartItem(cartItem: CartItem)

    @Query("SELECT * FROM cart_items")
    suspend fun getAllCartItems(): List<CartItem>

}