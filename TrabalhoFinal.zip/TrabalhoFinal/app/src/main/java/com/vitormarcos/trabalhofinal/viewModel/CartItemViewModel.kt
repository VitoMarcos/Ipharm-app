package com.vitormarcos.trabalhofinal.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vitormarcos.trabalhofinal.data.entities.CartItem
import com.vitormarcos.trabalhofinal.data.entities.Remedio
import com.vitormarcos.trabalhofinal.data.entities.dao.CartItemDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class CartItemViewModel(private val cartItemDao: CartItemDao) : ViewModel() {


    private val _cartItems = MutableLiveData<List<CartItem>>()
    val cartItems: LiveData<List<CartItem>> = _cartItems

    // Buscar todos os itens do carrinho
    fun fetchCartItems() {
        viewModelScope.launch {
            val items = cartItemDao.getAll()
            _cartItems.value = items
        }
    }

    // Adicionar item ao carrinho
    fun addCartItem(cartItem: CartItem) {
        viewModelScope.launch {
            cartItemDao.insert(cartItem)
            fetchCartItems() // Atualiza a lista após adicionar
        }
    }

    // Deletar item do carrinho
    fun deleteCartItem(cartItemId: Int) {
        viewModelScope.launch {
            cartItemDao.deleteById(cartItemId)
            fetchCartItems() // Atualiza a lista após deletar
        }
    }
}
