package com.vitormarcos.trabalhofinal.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vitormarcos.trabalhofinal.data.entities.Usuario
import com.vitormarcos.trabalhofinal.database.AppDatabase
import kotlinx.coroutines.launch

class UsuarioViewModel(private val database: AppDatabase) : ViewModel() {

    private val _usuarios = MutableLiveData<List<Usuario>>()
    val usuarios: LiveData<List<Usuario>> = _usuarios

    fun fetchUsuarios() {
        viewModelScope.launch {
            _usuarios.value = database.usuarioDao().getAllUsuarios()
        }
    }

    fun addUsuario(usuario: Usuario) {
        viewModelScope.launch {
            database.usuarioDao().insert(usuario)
            fetchUsuarios() // Atualiza a lista após adicionar
        }
    }

}
