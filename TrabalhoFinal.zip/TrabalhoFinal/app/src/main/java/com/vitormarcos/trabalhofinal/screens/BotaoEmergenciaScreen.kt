package com.vitormarcos.trabalhofinal.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material.FloatingActionButton
import androidx.compose.material.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.runtime.Composable

@Composable
fun EmergencyButton() {
    Box(modifier = Modifier.fillMaxSize()) {
        FloatingActionButton(
            onClick = { /* Acionar a funcionalidade de emergência */ },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(Icons.Default.Warning, contentDescription = "Emergência")
        }
    }
}
