package com.vitormarcos.trabalhofinal.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vitormarcos.trabalhofinal.data.entities.Remedio
import com.vitormarcos.trabalhofinal.data.entities.dao.RemedioDao
import kotlinx.coroutines.launch

class RemedioViewModel(private val remedioDao: RemedioDao) : ViewModel() {

    private val _remedios = MutableLiveData<List<Remedio>>()
    val remedios: LiveData<List<Remedio>> = _remedios

    // Buscar todos os remédios
    fun fetchRemedios() {
        viewModelScope.launch {
            val items = remedioDao.getAll()
            _remedios.value = items
        }
    }

    // Adicionar remédio
    fun addRemedio(remedio: Remedio) {
        viewModelScope.launch {
            remedioDao.insert(remedio)
            fetchRemedios() // Atualiza a lista após adicionar
        }
    }

    // Deletar remédio
    fun deleteRemedio(remedioId: Int) {
        viewModelScope.launch {
            remedioDao.deleteById(remedioId)
            fetchRemedios() // Atualiza a lista após deletar
        }
    }
}
