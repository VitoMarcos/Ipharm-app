package com.vitormarcos.trabalhofinal.data.entities.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.vitormarcos.trabalhofinal.data.entities.Remedio
import kotlinx.coroutines.flow.Flow

@Dao
interface RemedioDao {

    // Método para pegar um Remédio por ID de forma assíncrona
    @Query("SELECT * FROM remedios WHERE id = :id")
    suspend fun getById(id: Long): Remedio?

    // Método para pegar todos os Remédios de forma assíncrona
    @Query("SELECT * FROM remedios")
    suspend fun getAll(): List<Remedio>

    // Função para deletar item pelo ID
    @Query("DELETE FROM remedios WHERE id = :remedioId")
    suspend fun deleteById(remedioId: Int)

    // Método para inserir um remédio
    @Insert
    suspend fun insert(remedio: Remedio)

    // Método para atualizar um remédio
    @Update
    suspend fun update(remedio: Remedio)

    // Método para excluir um remédio
    @Delete
    suspend fun delete(remedio: Remedio)
}