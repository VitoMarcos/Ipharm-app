package com.vitormarcos.trabalhofinal.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Info

data class Pedido(val id: Int, val status: String)

@Composable
fun OrdersScreen() {
    val pedidos = remember {
        listOf(
            Pedido(1, "Concluído"),
            Pedido(2, "Em andamento"),
            Pedido(3, "Pendente")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Cabeçalho da lista
        Text(
            text = "Pedidos do Cliente",
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            modifier = Modifier
                .padding(bottom = 16.dp)
                .fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        // Lista de pedidos
        LazyColumn {
            items(pedidos) { pedido ->
                PedidoCard(pedido) // Passar um único pedido
            }
        }
    }
}

@Composable
fun PedidoCard(pedido: Pedido) {
    // Determinar a cor de fundo e o ícone com base no status
    val (statusColor, icon) = when (pedido.status) {
        "Concluído" -> Color.Green to Icons.Default.CheckCircle
        "Em andamento" -> Color.Yellow to Icons.Default.Info
        "Pendente" -> Color.Red to Icons.Default.Warning
        else -> Color.Gray to Icons.Default.Info
    }

    Card(
        backgroundColor = Color.LightGray,
        shape = RoundedCornerShape(8.dp),
        elevation = 4.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)  // Espaçamento entre os cartões
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Ícone com base no status
            Icon(
                imageVector = icon,
                contentDescription = "Status do Pedido",
                tint = statusColor,
                modifier = Modifier.size(24.dp)
            )
            Column(
                modifier = Modifier.padding(start = 16.dp)
            ) {
                Text(
                    text = "Pedido #${pedido.id}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = pedido.status,
                    color = statusColor,
                    fontSize = 14.sp
                )
            }
        }
    }
}
