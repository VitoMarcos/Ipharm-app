package com.vitormarcos.trabalhofinal.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vitormarcos.trabalhofinal.data.entities.CartItem
import com.vitormarcos.trabalhofinal.viewModel.CartItemViewModel
import androidx.compose.ui.platform.LocalContext

@Composable
fun CartScreen(cartItemViewModel: CartItemViewModel = viewModel()) {
    val context = LocalContext.current // Obtém o contexto da tela
    val cartItems by cartItemViewModel.cartItems.observeAsState(emptyList())

    // Calcular o total do carrinho
    val total = cartItems.sumOf { it.remedioPreco * it.quantidade }

    Column(modifier = Modifier.fillMaxSize()) {
        // Lista de itens do carrinho
        LazyColumn(modifier = Modifier.weight(1f).padding(16.dp)) {
            items(cartItems) { cartItem ->
                CartItemRow(
                    cartItem = cartItem,
                    onRemove = {
                        cartItemViewModel.deleteCartItem(cartItem.id)
                        NotificationHelper.sendNotification(
                            context,  // Usando o contexto diretamente
                            "Item Removido",
                            "Você removeu o item ${cartItem.remedioNome} do carrinho."
                        )
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        // Exibir total e botão para finalizar o pedido
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Total: R$ ${"%.2f".format(total)}", style = MaterialTheme.typography.h6)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    // Lógica para finalizar o pedido
                    NotificationHelper.sendNotification(
                        context,  // Usando o contexto diretamente
                        "Pedido Finalizado",
                        "Seu pedido foi finalizado com sucesso!"
                    )
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("Finalizar Pedido")
            }
        }

        // Botão de Emergência
        Button(
            onClick = {
                // Ação de emergência
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:190"))
                context.startActivity(intent)  // Usando o contexto diretamente
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.CenterHorizontally)
        ) {
            Text("Emergência")
        }
    }
}

@Composable
fun CartItemRow(cartItem: CartItem, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(text = cartItem.remedioNome, style = MaterialTheme.typography.body1)
            Text(
                text = "R$ ${"%.2f".format(cartItem.remedioPreco)} x ${cartItem.quantidade}",
                style = MaterialTheme.typography.body2
            )
        }
        Button(onClick = onRemove) {
            Text("Remover")
        }
    }
}
