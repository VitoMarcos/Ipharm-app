package com.vitormarcos.trabalhofinal.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "remedios")
data class Remedio(
    @PrimaryKey val id: Long,
    val nome: String,
    val descricao: String,
    val preco: Double,
    val foto: Int
)
