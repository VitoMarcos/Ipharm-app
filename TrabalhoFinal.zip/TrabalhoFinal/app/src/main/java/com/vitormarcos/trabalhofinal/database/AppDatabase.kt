package com.vitormarcos.trabalhofinal.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.vitormarcos.trabalhofinal.data.entities.CartItem
import com.vitormarcos.trabalhofinal.data.entities.Remedio
import com.vitormarcos.trabalhofinal.data.entities.Usuario
import com.vitormarcos.trabalhofinal.data.entities.dao.CartItemDao
import com.vitormarcos.trabalhofinal.data.entities.dao.RemedioDao
import com.vitormarcos.trabalhofinal.data.entities.dao.UsuarioDao

@Database(
    entities = [Remedio::class, CartItem::class, Usuario::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun remedioDao(): RemedioDao
    abstract fun cartItemDao(): CartItemDao
    abstract fun usuarioDao(): UsuarioDao // DAO do Usuario

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ipharm_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
